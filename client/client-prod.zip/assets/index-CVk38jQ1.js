(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=null,t=new Set;function n(n){e={view_stage:e?e.view_stage:`SERVER_SELECT`,rooms:e?e.rooms:[],mode:e?e.mode:null,...n};for(let n of t)try{n(e)}catch(e){console.error(`[State] Listener error:`,e)}}function r(){return e}function i(e){return t.add(e),()=>t.delete(e)}var a=null,o=null,s=1e3,c=1e4,l=`disconnected`,u=new Set,d=null;function f(e){d=e}function p(e=`ws://127.0.0.1:8080`){a&&(a.readyState===WebSocket.OPEN||a.readyState===WebSocket.CONNECTING)&&a.close(),v(`connecting`),console.log(`[Network] Connecting to ${e}...`);try{a=new WebSocket(e)}catch(t){console.error(`[Network] WebSocket creation failed:`,t),y(e);return}let t=a;a.addEventListener(`open`,()=>{a===t&&(console.log(`[Network] Connected`),s=1e3,v(`connected`))}),a.addEventListener(`message`,e=>{if(a===t)try{let t=JSON.parse(e.data);d&&d(t)}catch(e){console.error(`[Network] Failed to parse message:`,e)}}),a.addEventListener(`close`,n=>{if(a!==t){console.log(`[Network] Discarded old socket close event ignored`);return}console.log(`[Network] Disconnected (code: ${n.code})`),v(`disconnected`),y(e)}),a.addEventListener(`error`,e=>{a===t&&console.error(`[Network] Error:`,e)})}function m(e){if(!a||a.readyState!==WebSocket.OPEN){console.warn(`[Network] Cannot send — not connected`);return}a.send(JSON.stringify(e))}function h(){clearTimeout(o),a&&=(a.close(),null),v(`disconnected`)}function g(){return l}function _(e){return u.add(e),()=>u.delete(e)}function v(e){l=e;for(let e of u)e(l)}function y(e){clearTimeout(o),console.log(`[Network] Reconnecting in ${s}ms...`),o=setTimeout(()=>{s=Math.min(s*2,c),p(e)},s)}function b(e){console.log(`[Client Interaction] ${e}`);try{m({action:`client_log`,message:e})}catch{}}var x=new Set([`DEALING`,`BETTING`,`PLAYING`,`ROUND_END`]),S={},C=null,w=null,T=new Map;function E(){S.LOBBY=document.getElementById(`stage-lobby`),S.DEALING=document.getElementById(`stage-dealing`),S.BETTING=document.getElementById(`stage-betting`),S.PLAYING=document.getElementById(`stage-playing`),S.ROUND_END=document.getElementById(`stage-round-end`),S.GAME_OVER=document.getElementById(`stage-game-over`),C=document.getElementById(`hud`)}function D(e,t){T.set(e,t)}function O(e){if(!e||!e.current_stage)return;let t=e.current_stage;w!==t&&b(`Stage transitioned from ${w||`None`} to ${t}`);for(let[e,n]of Object.entries(S))e===t?n.classList.add(`active`):n.classList.remove(`active`);C&&(C.style.display=x.has(t)?``:`none`);let n=T.get(t),r=S[t];n&&r&&n(e,r);let i=document.getElementById(`dev-stage-label`);i&&(i.textContent=t),w=t}var k=[`hearts`,`diamonds`,`clubs`,`spades`];function A(){return{suit:k[Math.floor(Math.random()*4)],value:Math.floor(Math.random()*13)+2}}function j(e){let t=[];for(let n=0;n<e;n++)t.push(A());return t}var M={LOBBY:{current_stage:`LOBBY`,game_stats:{round:0,target_score:100},players:[{id:`p1`,name:`You`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``}],my_hand:[],table_cards:[],prompt_data:null,trick_winner:null,winner:null},DEALING:{current_stage:`DEALING`,game_stats:{round:1,target_score:100},players:[{id:`p1`,name:`You`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``},{id:`p2`,name:`Alice`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``},{id:`p3`,name:`Bob`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``},{id:`p4`,name:`Carol`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``}],my_hand:j(13),table_cards:[],prompt_data:null,trick_winner:null,winner:null},BETTING:{current_stage:`BETTING`,game_stats:{round:1,target_score:100},players:[{id:`p1`,name:`You`,score:0,tricks_taken:0,is_turn:!0,cards_played:[],bet:null,status:``},{id:`p2`,name:`Alice`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:3,status:`Bet 3`},{id:`p3`,name:`Bob`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:`Thinking...`},{id:`p4`,name:`Carol`,score:0,tricks_taken:0,is_turn:!1,cards_played:[],bet:5,status:`Bet 5`}],my_hand:[{suit:`spades`,value:14},{suit:`spades`,value:13},{suit:`hearts`,value:12},{suit:`hearts`,value:10},{suit:`hearts`,value:7},{suit:`diamonds`,value:14},{suit:`diamonds`,value:9},{suit:`diamonds`,value:5},{suit:`clubs`,value:11},{suit:`clubs`,value:8},{suit:`clubs`,value:6},{suit:`clubs`,value:3},{suit:`spades`,value:4}],table_cards:[],prompt_data:{min_bet:0,max_bet:13},trick_winner:null,winner:null},PLAYING:{current_stage:`PLAYING`,game_stats:{round:1,target_score:100},players:[{id:`p1`,name:`You`,score:12,tricks_taken:2,is_turn:!0,cards_played:[],bet:4,status:``},{id:`p2`,name:`Alice`,score:8,tricks_taken:1,is_turn:!1,cards_played:[],bet:3,status:``},{id:`p3`,name:`Bob`,score:15,tricks_taken:2,is_turn:!1,cards_played:[],bet:2,status:``},{id:`p4`,name:`Carol`,score:10,tricks_taken:3,is_turn:!1,cards_played:[],bet:5,status:``}],my_hand:[{suit:`spades`,value:14},{suit:`hearts`,value:12},{suit:`hearts`,value:7},{suit:`diamonds`,value:14},{suit:`diamonds`,value:9},{suit:`clubs`,value:11},{suit:`clubs`,value:8},{suit:`clubs`,value:3}],table_cards:[{player_id:`p2`,card:{suit:`clubs`,value:12}},{player_id:`p3`,card:{suit:`clubs`,value:5}},{player_id:`p4`,card:{suit:`clubs`,value:14}}],prompt_data:null,trick_winner:null,winner:null},ROUND_END:{current_stage:`ROUND_END`,game_stats:{round:1,target_score:100},players:[{id:`p1`,name:`You`,score:38,tricks_taken:4,is_turn:!1,cards_played:[],bet:4,status:``,score_change:26},{id:`p2`,name:`Alice`,score:27,tricks_taken:3,is_turn:!1,cards_played:[],bet:3,status:``,score_change:19},{id:`p3`,name:`Bob`,score:5,tricks_taken:1,is_turn:!1,cards_played:[],bet:2,status:``,score_change:-10},{id:`p4`,name:`Carol`,score:45,tricks_taken:5,is_turn:!1,cards_played:[],bet:5,status:``,score_change:35}],my_hand:[],table_cards:[],prompt_data:null,trick_winner:null,winner:null},GAME_OVER:{current_stage:`GAME_OVER`,game_stats:{round:8,target_score:100},players:[{id:`p1`,name:`You`,score:102,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``},{id:`p2`,name:`Alice`,score:87,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``},{id:`p3`,name:`Bob`,score:64,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``},{id:`p4`,name:`Carol`,score:111,tricks_taken:0,is_turn:!1,cards_played:[],bet:null,status:``}],my_hand:[],table_cards:[],prompt_data:null,trick_winner:null,winner:{id:`p4`,name:`Carol`}}};function N(e){return structuredClone(M[e]||M.LOBBY)}var P=[{stage:`LOBBY`,title:`1. Lobby & Matchmaking`,text:`Welcome to Israeli Whist! This is the main menu. Here, you can select "Play Offline vs Bots" to start a solo game instantly, or "Online Multiplayer" to browse, join, or create public and private rooms.`},{stage:`DEALING`,title:`2. Dealing Phase`,text:`When a game session begins, the cards are dealt. Each of the 4 players receives 13 cards. Bots are automatically assigned to any empty seats to keep the game moving.`},{stage:`BETTING`,title:`3. Contract Bidding`,text:`Bidding has 2 stages: 1. determining the leader and trump suit 2. determining each player's takes according to the trump suit. There are 'over' games that are aggressive (someone won't take enough!) and 'under' games that are surprising (someone will take too much!).`},{stage:`PLAYING`,title:`4. Gameplay Trick Loop`,text:`During play, you must follow the lead suit if you have it in hand. If you do not, you can play a trump card to "cut" the trick, or discard any other card. The player with the highest card of the lead suit (or highest trump) wins the trick.`},{stage:`ROUND_END`,title:`5. Round Results Breakdown`,text:`At the end of 13 tricks, the round is scored. Players who exactly made their bid earn bonus points (e.g. 10 + bid^2). Missing your bid loses points. Everyone must click "Next Round" to proceed.`},{stage:`GAME_OVER`,title:`6. Match Completed`,text:`The game ends when any player reaches the target score (usually 100 points). The player with the highest score wins the match! You can click "Return to Lobby" to start again.`}];function F(){I(0)}function I(e){let t=P[e];if(!t)return;let r=N(t.stage);r.in_tutorial=!0,r.tutorial_step=e,n(r),R(e)}function L(){let e=document.getElementById(`tutorial-guide-overlay`);e&&e.remove(),n({current_stage:`LOBBY`,players:[],my_hand:[],table_cards:[],prompt_data:null,trick_winner:null,winner:null,in_tutorial:!1})}function R(e){let t=P[e];if(!t)return;let n=document.getElementById(`tutorial-guide-overlay`);n||(n=document.createElement(`div`),n.id=`tutorial-guide-overlay`,n.className=`fixed bottom-2 right-2 md:bottom-4 md:right-4 z-50 w-[calc(100%-1rem)] max-w-[260px] md:max-w-[320px] pointer-events-none`,document.body.appendChild(n)),n.innerHTML=`
    <div class="glass-opaque p-3.5 md:p-4 border border-amber-500/30 shadow-2xl flex flex-col gap-2 pointer-events-auto rounded-2xl relative">
      <div class="absolute top-2.5 right-2.5 text-[8px] md:text-[10px] uppercase font-black tracking-widest text-amber-400 bg-amber-950/40 px-2 py-0.5 rounded">
        Step ${e+1} of ${P.length}
      </div>
      
      <div class="flex flex-col gap-1 text-left">
        <h4 class="text-xs md:text-sm font-black text-amber-400 uppercase tracking-wider pr-16">${t.title}</h4>
        <p class="text-[10px] md:text-xs text-slate-300 font-medium leading-relaxed mt-1">${t.text}</p>
      </div>

      <div class="flex justify-between items-center mt-1 md:mt-2 pt-2 md:pt-3 border-t border-slate-800">
        <button id="btn-tutorial-exit" class="btn btn-secondary text-[10px] md:text-xs !py-1 md:!py-1.5 !px-2 md:!px-3">
          Exit
        </button>
        <div class="flex gap-1.5">
          <button id="btn-tutorial-prev" class="btn btn-secondary text-[10px] md:text-xs !py-1 md:!py-1.5 !px-2 md:!px-3" ${e===0?`disabled opacity-40 cursor-not-allowed`:``}>
            ← Back
          </button>
          <button id="btn-tutorial-next" class="btn btn-primary text-[10px] md:text-xs !py-1 md:!py-1.5 !px-2.5 md:!px-4">
            ${e===P.length-1?`Finish`:`Next →`}
          </button>
        </div>
      </div>
    </div>
  `;let r=n.querySelector(`#btn-tutorial-exit`),i=n.querySelector(`#btn-tutorial-prev`),a=n.querySelector(`#btn-tutorial-next`);r.addEventListener(`click`,()=>{L()}),e>0&&i.addEventListener(`click`,()=>{I(e-1)}),a.addEventListener(`click`,()=>{e===P.length-1?L():I(e+1)})}function z(){let e=document.getElementById(`settings-menu-overlay`);if(e){b(`Settings menu toggled close`),e._cleanup&&e._cleanup(),e.remove();return}b(`Settings menu opened`);let t=parseInt(localStorage.getItem(`whist_text_size`)||`18`,10),i=parseInt(localStorage.getItem(`whist_card_spacing`)||`32`,10),a=parseInt(localStorage.getItem(`whist_felt_brightness`)||`100`,10),o=localStorage.getItem(`whist_theme`)||`dark`,s=localStorage.getItem(`whist_show_round_stats`)!==`false`,c=localStorage.getItem(`whist_show_opp_cards`)!==`false`,l=localStorage.getItem(`whist_show_chat`)!==`false`,u=r()||{},d=u.current_stage||`LOBBY`,f=u.players||[],v=f[0]||null,y=v?v.id===`p1`:!0,x=d===`LOBBY`&&y,S=u.settings||{end_condition:`score`,target_score:100,target_rounds:8,exchange_cards_count:2,bot_difficulty:`hard`},C=`wss://israeli-whist-backend.fly.dev`,w=localStorage.getItem(`whist_server_url`)||C,T=f.length>0,E=g(),D=`border-slate-800 text-slate-500 bg-slate-900/40`,O=`Disconnected`;E===`connected`?(D=`border-emerald-500/20 text-emerald-400 bg-emerald-950/10`,O=`Connected`):E===`connecting`&&(D=`border-amber-500/20 text-amber-400 bg-amber-950/20`,O=`Connecting`),e=document.createElement(`div`),e.id=`settings-menu-overlay`,e.className=`fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 pointer-events-auto`,e.innerHTML=`
    <div class="glass-opaque p-6 md:p-8 max-w-md w-full mx-4 border border-slate-800 flex flex-col shadow-2xl relative rounded-2xl max-h-[90vh] overflow-hidden">
      <!-- Header -->
      <div class="flex border-b border-slate-800 pb-3 mb-5">
        <button id="tab-visuals" class="flex-1 text-center py-2 text-xs font-black uppercase tracking-wider text-amber-400 border-b-2 border-amber-500">Visuals</button>
        <button id="tab-server" class="flex-1 text-center py-2 text-xs font-black uppercase tracking-wider text-slate-400 border-b-2 border-transparent">Server</button>
        <button id="tab-rules" class="flex-1 text-center py-2 text-xs font-black uppercase tracking-wider text-slate-400 border-b-2 border-transparent">Game Rules</button>
      </div>

      <!-- Tab Content Container -->
      <div id="settings-tab-content" class="flex-1 overflow-y-auto pr-1 mb-6">
        <!-- Visual Settings -->
        <div id="panel-visuals" class="flex flex-col gap-5">
          <!-- Theme selector -->
          <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
            <span>Theme Mode</span>
            <select id="theme-selector" class="input py-1 text-xs font-semibold">
              <option value="dark" ${o===`dark`?`selected`:``}>Dark Mode</option>
              <option value="light" ${o===`light`?`selected`:``}>Light Mode</option>
            </select>
          </div>

          <!-- Text Size Slider -->
          <div class="flex flex-col gap-1.5">
            <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
              <span>Text Size</span>
              <span id="text-size-val" class="font-mono text-amber-400 text-sm">${t}px</span>
            </div>
            <input type="range" id="text-size-slider" min="12" max="28" value="${t}" class="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
          </div>

          <!-- Card Offset/Spacing Slider -->
          <div class="flex flex-col gap-1.5">
            <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
              <span>Card Fan Spacing</span>
              <span id="card-spacing-val" class="font-mono text-amber-400 text-sm">${i}px</span>
            </div>
            <input type="range" id="card-spacing-slider" min="15" max="60" value="${i}" class="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
          </div>

          <!-- Table Felt Brightness Slider -->
          <div class="flex flex-col gap-1.5">
            <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
              <span>Table Brightness</span>
              <span id="brightness-val" class="font-mono text-amber-400 text-sm">${a}%</span>
            </div>
            <input type="range" id="brightness-slider" min="30" max="200" value="${a}" class="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
          </div>

          <!-- HUD Toggles -->
          <div class="flex flex-col gap-3 border-t border-slate-800/60 pt-4">
            <label class="flex items-center gap-3 cursor-pointer text-xs font-bold uppercase text-slate-300 select-none">
              <input type="checkbox" id="toggle-round-stats" class="accent-emerald-500 rounded" ${s?`checked`:``} />
              <span>Show Round Stats Badge</span>
            </label>
            <label class="flex items-center gap-3 cursor-pointer text-xs font-bold uppercase text-slate-300 select-none">
              <input type="checkbox" id="toggle-opp-cards" class="accent-emerald-500 rounded" ${c?`checked`:``} />
              <span>Show Opponent Hand Counts</span>
            </label>
            <label class="flex items-center gap-3 cursor-pointer text-xs font-bold uppercase text-slate-300 select-none">
              <input type="checkbox" id="toggle-chat" class="accent-emerald-500 rounded" ${l?`checked`:``} />
              <span>Show Lobby Chat Box</span>
            </label>
          </div>
        </div>

        <!-- Server Settings -->
        <div id="panel-server" class="flex flex-col gap-5 hidden">
          <!-- Connection Status -->
          <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
            <span>Connection Status</span>
            <span id="server-status-badge" class="px-2 py-0.5 rounded font-black text-[10px] uppercase tracking-wider border ${D}">${O}</span>
          </div>

          <!-- Server URL Input -->
          <div class="flex flex-col gap-2">
            <label class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">WebSocket Server URL</label>
            <input type="text" id="settings-server-url" class="input w-full text-sm font-mono" placeholder="${C}" value="${w}" ${T?`disabled`:``} />
            <div id="settings-server-url-error" class="text-rose-400 text-[10px] font-bold mt-1 hidden"></div>
          </div>

          <!-- Helper instructions -->
          <p class="text-[11px] text-slate-400 leading-normal">
            The client connects to this Erlang WebSocket server to host rooms and process game logic.
          </p>

          ${T?`
            <div class="glass-sm p-3 border border-amber-500/20 text-amber-400 text-[11px] font-semibold text-center leading-relaxed">
              ⚠️ Leave your current match or waiting room to modify the Server URL.
            </div>
          `:`
            <div class="flex gap-2">
              <button id="btn-reset-server-url" class="btn btn-secondary flex-1 py-2 text-xs font-bold">
                Reset Default
              </button>
              <button id="btn-save-server-url" class="btn btn-gold flex-1 py-2 text-xs font-bold">
                Save & Connect
              </button>
            </div>
          `}
        </div>

        <!-- Game Rules Settings -->
        <div id="panel-rules" class="flex flex-col gap-5 hidden">
          ${x?``:`
            <div class="glass-sm p-3 border border-amber-500/20 text-amber-400 text-[11px] font-semibold text-center leading-relaxed mb-2">
              ⚠️ Game rules can only be modified in the waiting Lobby by the room Host.
            </div>
          `}

          <!-- Ending Condition -->
          <div class="flex flex-col gap-2">
            <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
              <span>Ending Condition</span>
              <select id="rules-end-condition" class="input py-1 text-xs font-semibold" ${x?``:`disabled`}>
                <option value="score" ${S.end_condition===`score`?`selected`:``}>Target Score</option>
                <option value="rounds" ${S.end_condition===`rounds`?`selected`:``}>Number of Rounds</option>
              </select>
            </div>
          </div>

          <!-- Target Score -->
          <div id="rule-score-container" class="flex flex-col gap-1.5 ${S.end_condition===`rounds`?`hidden`:``}">
            <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
              <span>Target Score Limit</span>
              <span id="rules-score-val" class="font-mono text-amber-400 text-sm">${S.target_score} pts</span>
            </div>
            <input type="range" id="rules-score-slider" min="50" max="300" step="25" value="${S.target_score}" class="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500" ${x?``:`disabled`} />
          </div>

          <!-- Target Rounds -->
          <div id="rule-rounds-container" class="flex flex-col gap-1.5 ${S.end_condition===`rounds`?``:`hidden`}">
            <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
              <span>Max Round Limit</span>
              <span id="rules-rounds-val" class="font-mono text-amber-400 text-sm">${S.target_rounds} rounds</span>
            </div>
            <input type="range" id="rules-rounds-slider" min="3" max="20" value="${S.target_rounds}" class="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500" ${x?``:`disabled`} />
          </div>

          <!-- Cards in Exchange -->
          <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
            <span>Cards in Exchange</span>
            <select id="rules-exchange-cards" class="input py-1 text-xs font-semibold" ${x?``:`disabled`}>
              <option value="0" ${parseInt(S.exchange_cards_count,10)===0?`selected`:``}>0 (No Exchange)</option>
              <option value="1" ${parseInt(S.exchange_cards_count,10)===1?`selected`:``}>1 Card</option>
              <option value="2" ${parseInt(S.exchange_cards_count,10)===2||S.exchange_cards_count===void 0?`selected`:``}>2 Cards (Standard)</option>
              <option value="3" ${parseInt(S.exchange_cards_count,10)===3?`selected`:``}>3 Cards</option>
            </select>
          </div>

          <!-- Bot Difficulty -->
          <div class="flex justify-between items-center text-xs font-bold uppercase tracking-wide text-slate-300">
            <span>Bot Play Difficulty</span>
            <select id="rules-bot-difficulty" class="input py-1 text-xs font-semibold" ${x?``:`disabled`}>
              <option value="easy" ${S.bot_difficulty===`easy`?`selected`:``}>Easy Mode</option>
              <option value="hard" ${S.bot_difficulty===`hard`||S.bot_difficulty===void 0?`selected`:``}>Hard Mode</option>
            </select>
          </div>

          <!-- Apply Rules Button -->
          ${x?`
            <button id="btn-apply-rules" class="btn btn-gold w-full py-2 text-xs font-bold mt-2">
              Apply Rules Settings
            </button>
          `:``}
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="flex flex-col gap-3 w-full border-t border-slate-800 pt-4">
        <button id="btn-settings-close" class="btn btn-primary w-full py-2.5 text-xs font-bold">
          Close Settings
        </button>
        ${f.length>0?`
          <button id="btn-settings-exit" class="btn btn-danger w-full py-2.5 text-xs font-bold">
            Exit Game
          </button>
        `:``}
      </div>
    </div>
  `,document.body.appendChild(e);let k=e.querySelector(`#tab-visuals`),A=e.querySelector(`#tab-server`),j=e.querySelector(`#tab-rules`),M=e.querySelector(`#panel-visuals`),N=e.querySelector(`#panel-server`),P=e.querySelector(`#panel-rules`),F=e=>{[{btn:k,panel:M},{btn:A,panel:N},{btn:j,panel:P}].forEach(t=>{t.btn===e?(t.btn.className=`flex-1 text-center py-2 text-xs font-black uppercase tracking-wider text-amber-400 border-b-2 border-amber-500`,t.panel.classList.remove(`hidden`)):(t.btn.className=`flex-1 text-center py-2 text-xs font-black uppercase tracking-wider text-slate-400 border-b-2 border-transparent`,t.panel.classList.add(`hidden`))})};k.addEventListener(`click`,()=>F(k)),A.addEventListener(`click`,()=>F(A)),j.addEventListener(`click`,()=>F(j));let I=e.querySelector(`#server-status-badge`),L=_(e=>{if(!I)return;let t=`border-slate-800 text-slate-500 bg-slate-900/40`,n=`Disconnected`;e===`connected`?(t=`border-emerald-500/20 text-emerald-400 bg-emerald-950/10`,n=`Connected`):e===`connecting`&&(t=`border-amber-500/20 text-amber-400 bg-amber-950/20`,n=`Connecting`),I.className=`px-2 py-0.5 rounded font-black text-[10px] uppercase tracking-wider border ${t}`,I.textContent=n});e._cleanup=L;let R=null,z=null,B=()=>{R&&R(),clearTimeout(z),e._cleanup&&e._cleanup(),e.remove()};if(!T){let t=e.querySelector(`#settings-server-url`),n=e.querySelector(`#btn-reset-server-url`),r=e.querySelector(`#btn-save-server-url`),i=e.querySelector(`#settings-server-url-error`);n.addEventListener(`click`,()=>{b(`Button Click: Reset Server URL to Default`),t.value=C,i&&i.classList.add(`hidden`)}),r.addEventListener(`click`,()=>{let e=t.value.trim();if(e){if(i&&i.classList.add(`hidden`),!e.startsWith(`ws://`)&&!e.startsWith(`wss://`)){i&&(i.textContent=`URL must start with ws:// or wss://`,i.classList.remove(`hidden`));return}b(`Button Click: Attempting Save & Connect Server URL: "${e}"`),r.disabled=!0,r.classList.add(`btn-loading`),n.disabled=!0,window.showLoading(`Connecting to server...`),localStorage.setItem(`whist_server_url`,e),p(e),R&&R(),clearTimeout(z),z=setTimeout(()=>{R&&R(),r.disabled=!1,r.classList.remove(`btn-loading`),r.textContent=`Save & Connect`,n.disabled=!1,window.hideLoading(),i&&(i.textContent=`Connection timeout. Check server status.`,i.classList.remove(`hidden`))},5e3),R=_(e=>{e===`connected`&&(clearTimeout(z),R&&R(),r.classList.remove(`btn-loading`),r.textContent=`Connected! ✓`,r.className=`btn btn-primary flex-1 py-2 text-xs font-bold`,setTimeout(()=>{B()},800))})}})}let V=e.querySelector(`#theme-selector`),H=e.querySelector(`#text-size-slider`),U=e.querySelector(`#text-size-val`),W=e.querySelector(`#card-spacing-slider`),G=e.querySelector(`#card-spacing-val`),K=e.querySelector(`#brightness-slider`),q=e.querySelector(`#brightness-val`),J=e.querySelector(`#toggle-round-stats`),Y=e.querySelector(`#toggle-opp-cards`),X=e.querySelector(`#toggle-chat`),Z=e.querySelector(`#btn-settings-close`),Q=e.querySelector(`#btn-settings-exit`);if(V.addEventListener(`change`,()=>{let e=V.value;localStorage.setItem(`whist_theme`,e),e===`light`?document.body.classList.add(`light-theme`):document.body.classList.remove(`light-theme`),b(`Setting Changed: Theme set to ${e}`)}),H.addEventListener(`input`,()=>{let e=H.value;U.textContent=`${e}px`,localStorage.setItem(`whist_text_size`,e),document.documentElement.style.fontSize=`${e}px`,b(`Setting Changed: Text Size set to ${e}px`)}),W.addEventListener(`input`,()=>{let e=W.value;G.textContent=`${e}px`,localStorage.setItem(`whist_card_spacing`,e),b(`Setting Changed: Card Spacing set to ${e}px`),n({...r()})}),K.addEventListener(`input`,()=>{let e=K.value;q.textContent=`${e}%`,localStorage.setItem(`whist_felt_brightness`,e),document.documentElement.style.setProperty(`--table-brightness`,e/100),b(`Setting Changed: Table Brightness set to ${e}%`)}),J.addEventListener(`change`,()=>{localStorage.setItem(`whist_show_round_stats`,J.checked),b(`Setting Changed: Show Round Stats Badge set to ${J.checked}`),n({...r()})}),Y.addEventListener(`change`,()=>{localStorage.setItem(`whist_show_opp_cards`,Y.checked),b(`Setting Changed: Show Opponent Hand Counts set to ${Y.checked}`),n({...r()})}),X.addEventListener(`change`,()=>{localStorage.setItem(`whist_show_chat`,X.checked),b(`Setting Changed: Show Lobby Chat Box set to ${X.checked}`),n({...r()})}),x){let t=e.querySelector(`#rules-end-condition`),n=e.querySelector(`#rule-score-container`),r=e.querySelector(`#rules-score-slider`),i=e.querySelector(`#rules-score-val`),a=e.querySelector(`#rule-rounds-container`),o=e.querySelector(`#rules-rounds-slider`),s=e.querySelector(`#rules-rounds-val`),c=e.querySelector(`#rules-exchange-cards`),l=e.querySelector(`#rules-bot-difficulty`),u=e.querySelector(`#btn-apply-rules`);t.addEventListener(`change`,()=>{t.value===`score`?(n.classList.remove(`hidden`),a.classList.add(`hidden`)):(n.classList.add(`hidden`),a.classList.remove(`hidden`))}),r.addEventListener(`input`,()=>{i.textContent=`${r.value} pts`}),o.addEventListener(`input`,()=>{s.textContent=`${o.value} rounds`}),u.addEventListener(`click`,()=>{let e={action:`update_settings`,settings:{end_condition:t.value,target_score:parseInt(r.value,10),target_rounds:parseInt(o.value,10),exchange_cards_count:parseInt(c.value,10),bot_difficulty:l.value}};m(e),b(`Applied Game Rules Settings: ${JSON.stringify(e.settings)}`),u.textContent=`Settings Applied! ✓`,u.className=`btn btn-primary w-full py-2 text-xs font-bold mt-2`,setTimeout(()=>{u.textContent=`Apply Rules Settings`,u.className=`btn btn-gold w-full py-2 text-xs font-bold mt-2`},1500)})}Z.addEventListener(`click`,()=>{b(`Button Click: Close Settings`),B()}),Q&&Q.addEventListener(`click`,()=>{b(`Button Click: Exit Game`),ee(u.mode===`offline`?`Game will not be saved. Still exit?`:`Are you sure you want to exit the match? You will be replaced by a bot.`,()=>{b(`Button Click: Confirm Exit Game`),B(),m({action:`leave_room`}),h(),n({current_stage:`LOBBY`,players:[],my_hand:[],table_cards:[],prompt_data:null,trick_winner:null,winner:null,view_stage:`SERVER_SELECT`,mode:null})})})}function ee(e,t){let n=document.createElement(`div`);n.className=`fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-[100] pointer-events-auto`,n.innerHTML=`
    <div class="glass-opaque p-6 max-w-sm w-full mx-4 border border-slate-800 flex flex-col items-center text-center shadow-2xl rounded-2xl animate-fade-in">
      <h3 class="text-base font-extrabold text-white mb-2">Confirm Action</h3>
      <p class="text-xs text-slate-400 mb-6 leading-relaxed">${e}</p>
      <div class="flex gap-3 w-full">
        <button id="confirm-cancel" class="btn btn-secondary flex-1 py-2 text-xs">Cancel</button>
        <button id="confirm-ok" class="btn btn-danger flex-1 py-2 text-xs">Confirm</button>
      </div>
    </div>
  `,document.body.appendChild(n);let r=n.querySelector(`#confirm-cancel`),i=n.querySelector(`#confirm-ok`);r.addEventListener(`click`,()=>{n.remove()}),i.addEventListener(`click`,()=>{n.remove(),t()})}var B=[];function V(e,t){t.innerHTML=``;let n=e.players||[];n.length===0?e.view_stage===`ROOM_LIST`?U(t,e):H(t):G(n,t,e)}function H(e){let t=document.createElement(`div`);t.className=`glass-opaque p-8 md:p-10 max-w-md w-full mx-4 flex flex-col items-center text-center shadow-2xl relative overflow-hidden`,t.innerHTML=`
    <!-- Floating decorative suit symbols -->
    <div class="absolute -top-10 -left-10 text-9xl text-slate-700/5 select-none font-bold">♠</div>
    <div class="absolute -bottom-10 -right-10 text-9xl text-slate-700/5 select-none font-bold">♥</div>
    <div class="absolute top-1/2 right-4 text-6xl text-slate-700/5 select-none font-bold">♦</div>
    <div class="absolute top-1/3 left-4 text-6xl text-slate-700/5 select-none font-bold">♣</div>

    <div class="relative z-10 w-full flex flex-col items-center">
      <h1 class="text-5xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-400 to-blue-500 mb-2">WHIST</h1>
      <div class="text-[10px] uppercase font-black tracking-widest text-emerald-400/80 mb-4 bg-emerald-950/40 px-2 py-0.5 rounded">Israeli Edition</div>
      <p class="text-slate-400 text-sm mb-4">A classic trick-taking card game. Choose a connection option to start.</p>

      <!-- Server Connection Selection -->
      <div class="flex flex-col gap-1.5 w-full mb-5 text-left relative z-20">
        <label class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Server Connection</label>
        <select id="select-server-url" class="input w-full py-2 px-3 text-xs font-semibold bg-slate-900 border border-slate-700 rounded text-slate-200">
          <option value="wss://israeli-whist-backend.fly.dev">Online Server (Fly.io)</option>
          <option value="ws://127.0.0.1:8080">Local Server (127.0.0.1)</option>
          <option value="custom">Custom Server URL...</option>
        </select>
        <input type="text" id="input-custom-server-url" class="input w-full text-xs font-mono mt-1.5 hidden bg-slate-900 border border-slate-700 rounded text-slate-200 py-1.5 px-3" placeholder="ws://127.0.0.1:8080" />
      </div>

      <div class="flex flex-col gap-4 w-full" id="menu-buttons">
        <button id="btn-offline" class="btn btn-primary text-base py-3.5 flex justify-center items-center gap-2">
          <span>⚡</span> Play Offline vs Bots
        </button>
        <button id="btn-show-online" class="btn btn-secondary text-base py-3.5 flex justify-center items-center gap-2">
          <span>🌐</span> Online Multiplayer
        </button>
        <button id="btn-tutorial" class="btn btn-secondary text-base py-3.5 flex justify-center items-center gap-2 border border-amber-500/25">
          <span>📖</span> Learn Tutorial
        </button>
        <button id="btn-main-settings" class="btn btn-secondary text-base py-3.5 flex justify-center items-center gap-2">
          <span>⚙️</span> Game Settings
        </button>
      </div>
    </div>
  `,e.appendChild(t);let i=t.querySelector(`#btn-offline`),a=t.querySelector(`#btn-show-online`),o=t.querySelector(`#btn-tutorial`),s=t.querySelector(`#btn-main-settings`),c=t.querySelector(`#select-server-url`),l=t.querySelector(`#input-custom-server-url`),u=`wss://israeli-whist-backend.fly.dev`,d=localStorage.getItem(`whist_server_url`)||u;d===`wss://israeli-whist-backend.fly.dev`?(c.value=`wss://israeli-whist-backend.fly.dev`,l.classList.add(`hidden`)):d===`ws://127.0.0.1:8080`?(c.value=`ws://127.0.0.1:8080`,l.classList.add(`hidden`)):(c.value=`custom`,l.value=d,l.classList.remove(`hidden`)),c.addEventListener(`change`,()=>{let e=c.value;if(e===`custom`){l.classList.remove(`hidden`),l.focus();let e=l.value.trim()||`ws://127.0.0.1:8080`;localStorage.setItem(`whist_server_url`,e)}else l.classList.add(`hidden`),l.classList.remove(`border-rose-500`),localStorage.setItem(`whist_server_url`,e)}),l.addEventListener(`input`,()=>{let e=l.value.trim();e&&localStorage.setItem(`whist_server_url`,e)}),window._lobbyStatusUnsubscribe&&window._lobbyStatusUnsubscribe(),window._lobbyStatusUnsubscribe=_(e=>{e===`disconnected`&&(i.disabled=!1,i.classList.remove(`btn-loading`),i.textContent=`⚡ Play Offline vs Bots`,a.disabled=!1,a.classList.remove(`btn-loading`),a.textContent=`🌐 Online Multiplayer`,window.hideLoading())});let f=e=>`${localStorage.getItem(`whist_server_url`)||u}?mode=${e}`,h=(e,t)=>{let n=localStorage.getItem(`whist_server_url`)||u;return!n.startsWith(`ws://`)&&!n.startsWith(`wss://`)?(l.classList.remove(`hidden`),l.classList.add(`border-rose-500`),l.focus(),t.disabled=!1,t.textContent=t.id===`btn-offline`?`⚡ Play Offline vs Bots`:`🌐 Online Multiplayer`,!1):(l.classList.remove(`border-rose-500`),p(f(e)),!0)};i.addEventListener(`click`,()=>{if(b(`Button Click: Play Offline vs Bots`),i.disabled=!0,i.classList.add(`btn-loading`),window.showLoading(`Starting Offline Match...`),h(`offline`,i)){let e=r()||{};e.mode=`offline`,n(e)}}),a.addEventListener(`click`,()=>{if(b(`Button Click: Online Multiplayer`),a.disabled=!0,a.classList.add(`btn-loading`),window.showLoading(`Connecting to Online Lobby...`),h(`online`,a)){let e=r()||{};e.mode=`online`,n(e);let t=_(e=>{if(e===`connected`){t();let e=r()||{};e.view_stage=`ROOM_LIST`,n(e),m({action:`list_rooms`})}})}}),o.addEventListener(`click`,()=>{b(`Button Click: Learn Tutorial`),F()}),s.addEventListener(`click`,()=>{b(`Button Click: Open Main Menu Settings`),z()})}function U(e,t){let i=t.rooms||[],a=document.createElement(`div`);a.className=`glass-opaque p-8 max-w-2xl w-full mx-4 flex flex-col shadow-2xl relative z-10 max-h-[90vh] overflow-hidden`,a.innerHTML=`
    <!-- Header -->
    <div class="flex justify-between items-center mb-6 pb-4 border-b border-slate-800">
      <div>
        <h2 class="text-2xl font-black text-white tracking-wide">Room Browser</h2>
        <p class="text-slate-400 text-xs mt-0.5">Select a room to play or spectate games</p>
      </div>
      <div class="flex gap-2">
        <button id="btn-refresh-rooms" class="btn btn-secondary text-xs !py-2 !px-3 flex items-center gap-1.5">
          🔄 Refresh
        </button>
        <button id="btn-create-room" class="btn btn-primary text-xs !py-2 !px-3 flex items-center gap-1.5">
          <span>+</span> Create Room
        </button>
      </div>
    </div>

    <!-- Rooms list -->
    <div class="flex-1 overflow-y-auto pr-1 flex flex-col gap-3 min-h-[250px] max-h-[350px] mb-6" id="rooms-list-container">
      ${i.length===0?`
        <div class="text-center py-12 text-slate-500 font-medium">
          No active rooms found. Click "Create Room" to start one!
        </div>
      `:i.map(e=>{let t=e.players>=e.maxPlayers,n=t?`bg-amber-500/10 text-amber-400 border-amber-500/20`:`bg-emerald-500/10 text-emerald-400 border-emerald-500/20`;return`
          <div class="glass-sm p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border border-slate-800 hover:border-slate-700 transition-colors">
            <div class="flex flex-col gap-1 text-left">
              <div class="flex items-center gap-2">
                <span class="text-sm font-bold text-white">${e.name}</span>
                ${e.hasPassword?`<span class="text-slate-400 text-[10px]">🔒 Private</span>`:`<span class="text-emerald-500/80 text-[10px]">🔓 Open</span>`}
              </div>
              <div class="flex gap-2 items-center">
                <span class="text-[10px] px-1.5 py-0.5 rounded border font-semibold ${n}">${e.players}/${e.maxPlayers} Players</span>
                <span class="text-[10px] text-slate-500 font-mono">ID: ${e.id}</span>
              </div>
            </div>
            
            <div class="flex gap-2 self-end md:self-auto">
              <button class="btn btn-secondary text-xs !py-1.5 !px-3 btn-spectate" data-id="${e.id}" data-private="${e.hasPassword}">
                👁️ Spectate
              </button>
              ${t?`
                <button class="btn btn-secondary text-xs !py-1.5 !px-4 opacity-50 cursor-not-allowed" disabled>
                  Room Full
                </button>
              `:`
                <button class="btn btn-primary text-xs !py-1.5 !px-4 btn-join" data-id="${e.id}" data-private="${e.hasPassword}">
                  ⚔️ Join Game
                </button>
              `}
            </div>
          </div>
        `}).join(``)}
    </div>

    <!-- Back to main menu -->
    <div class="flex justify-between items-center">
      <button id="btn-browser-back" class="btn btn-secondary text-xs !py-2 !px-4">
        ← Main Menu
      </button>
      <span class="text-[10px] text-slate-500 font-medium">Israeli Whist Room Broker active</span>
    </div>

    <!-- Sleek Password Modal (Hidden by Default) -->
    <div id="password-modal" class="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center hidden z-30">
      <div class="glass-opaque p-6 max-w-sm w-full mx-4 border border-slate-800 flex flex-col items-center text-center">
        <h3 class="text-lg font-black text-white uppercase tracking-wider mb-1">Enter Room Token</h3>
        <p class="text-xs text-slate-400 mb-6">This room requires a password or private access key.</p>
        
        <input type="password" id="room-password-input" class="input w-full text-center mb-6 font-mono text-lg tracking-widest" placeholder="••••••••" />
        
        <div class="flex gap-2 w-full">
          <button id="btn-modal-cancel" class="btn btn-secondary flex-1 py-2 text-xs">Cancel</button>
          <button id="btn-modal-submit" class="btn btn-primary flex-1 py-2 text-xs">Submit</button>
        </div>
      </div>
    </div>

    <!-- Sleek Create Room Modal (Hidden by Default) -->
    <div id="create-room-modal" class="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center hidden z-30">
      <div class="glass-opaque p-6 max-w-sm w-full mx-4 border border-slate-800 flex flex-col items-center text-center">
        <h3 class="text-lg font-black text-white uppercase tracking-wider mb-1">Create Room</h3>
        <p class="text-xs text-slate-400 mb-6">Set up your private or public Israeli Whist match.</p>
        
        <div class="flex flex-col gap-2 w-full mb-4 text-left">
          <label class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Room Name</label>
          <input type="text" id="create-room-name" class="input w-full text-sm" placeholder="New Whist Lounge" value="New Whist Lounge" maxlength="30" />
        </div>
        
        <div class="flex flex-col gap-2 w-full mb-6 text-left">
          <label class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Password / Token (Optional)</label>
          <input type="password" id="create-room-password" class="input w-full text-sm font-mono" placeholder="Leave blank for public room" />
        </div>
        
        <div class="flex gap-2 w-full">
          <button id="btn-create-cancel" class="btn btn-secondary flex-1 py-2.5 text-xs">Cancel</button>
          <button id="btn-create-submit" class="btn btn-primary flex-1 py-2.5 text-xs">Create</button>
        </div>
      </div>
    </div>
  `,e.appendChild(a);let o=a.querySelector(`#btn-browser-back`),s=a.querySelector(`#btn-create-room`),c=a.querySelector(`#btn-refresh-rooms`),l=a.querySelector(`#password-modal`),u=a.querySelector(`#btn-modal-cancel`),d=a.querySelector(`#btn-modal-submit`),f=a.querySelector(`#room-password-input`),p=a.querySelector(`#create-room-modal`),h=a.querySelector(`#btn-create-cancel`),g=a.querySelector(`#btn-create-submit`),_=a.querySelector(`#create-room-name`),v=a.querySelector(`#create-room-password`),y=null,x=`player`;o.addEventListener(`click`,()=>{b(`Button Click: Browser Back to Main Menu`);let e=r()||{};e.view_stage=`SERVER_SELECT`,n(e)}),s.addEventListener(`click`,()=>{_.value=`New Whist Lounge`,v.value=``,p.classList.remove(`hidden`),_.focus(),_.select()}),h.addEventListener(`click`,()=>{p.classList.add(`hidden`)}),g.addEventListener(`click`,()=>{let e=_.value.trim();if(!e)return;let t=v.value.trim();b(`Button Click: Create Room (name: "${e}", private: ${!!t})`),g.disabled=!0,h.disabled=!0,_.disabled=!0,v.disabled=!0,g.classList.add(`btn-loading`),window.showLoading(`Creating Room...`),m({action:`create_room`,name:e,password:t||null})}),_.addEventListener(`keydown`,e=>{e.key===`Enter`&&g.click()}),v.addEventListener(`keydown`,e=>{e.key===`Enter`&&g.click()}),c.addEventListener(`click`,()=>{b(`Button Click: Refresh Rooms List`),c.disabled=!0,c.classList.add(`btn-loading`),m({action:`list_rooms`}),setTimeout(()=>{c&&c.disabled&&(c.disabled=!1,c.classList.remove(`btn-loading`))},3e3)}),a.querySelectorAll(`.btn-join`).forEach(e=>{e.addEventListener(`click`,()=>{y=e.dataset.id,x=`player`;let t=e.dataset.private===`true`;b(`Button Click: Join Room (id: "${y}", private: ${t})`),t?(f.value=``,l.classList.remove(`hidden`),f.focus()):(a.querySelectorAll(`.btn-join, .btn-spectate`).forEach(e=>e.disabled=!0),e.classList.add(`btn-loading`),window.showLoading(`Joining Room...`),W(y,``,x))})}),a.querySelectorAll(`.btn-spectate`).forEach(e=>{e.addEventListener(`click`,()=>{y=e.dataset.id,x=`spectator`;let t=e.dataset.private===`true`;b(`Button Click: Spectate Room (id: "${y}", private: ${t})`),t?(f.value=``,l.classList.remove(`hidden`),f.focus()):(a.querySelectorAll(`.btn-join, .btn-spectate`).forEach(e=>e.disabled=!0),e.classList.add(`btn-loading`),window.showLoading(`Joining as Spectator...`),W(y,``,x))})}),u.addEventListener(`click`,()=>{b(`Button Click: Cancel Password Modal`),l.classList.add(`hidden`)}),d.addEventListener(`click`,()=>{let e=f.value.trim();e&&(b(`Button Click: Submit Password Modal`),d.disabled=!0,u.disabled=!0,f.disabled=!0,d.classList.add(`btn-loading`),window.showLoading(`Joining Room...`),W(y,e,x))}),f.addEventListener(`keydown`,e=>{e.key===`Enter`&&d.click()})}function W(e,t,n){m({action:`join_room`,room_id:e,password:t||null,role:n})}function G(e,t,i){let a=localStorage.getItem(`whist_show_chat`)!==`false`,o=document.createElement(`div`);a?o.className=`glass-opaque p-8 max-w-4xl w-full mx-4 flex flex-col md:flex-row gap-6 shadow-2xl relative rounded-2xl`:o.className=`glass-opaque p-8 max-w-xl w-full mx-4 flex flex-col gap-6 shadow-2xl relative rounded-2xl`;let s=e.length,c=i.is_spectator===!0,l=e[0]||{},u=l.id===`p1`,d=l.status===`Ready`,f=i.settings||{end_condition:`score`,target_score:100,target_rounds:8,exchange_cards_count:2,bot_difficulty:`hard`},p=f.end_condition===`rounds`?`${f.target_rounds} Rounds`:`${f.target_score} Points`,h=f.exchange_cards_count===0?`No Exchange`:`${f.exchange_cards_count} Cards`,g=f.bot_difficulty===`easy`?`Easy Bots`:`Hard Bots`;o.innerHTML=`
    <!-- Left Side: Players & Controls -->
    <div class="flex-1 flex flex-col items-center text-center">
      <!-- Header row containing title and settings button -->
      <div class="flex justify-between items-center w-full mb-3 pb-2 border-b border-slate-800/40">
        <h2 class="text-2xl font-black text-white tracking-wide">Waiting Room</h2>
        <button id="btn-waiting-room-settings" class="btn btn-secondary text-xs !py-1 !px-2.5 flex items-center gap-1">⚙️ Settings</button>
      </div>

      <div class="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1 pulse-soft">
        ${c?`Spectating Mode — Waiting for game launch`:`Waiting for players to join...`}
      </div>
      
      <!-- Active Rules Badges -->
      <div class="flex flex-wrap gap-2 justify-center mb-4">
        <span class="text-[9px] uppercase font-black tracking-wider px-2 py-0.5 rounded border border-slate-800 bg-slate-950/40 text-slate-400">Goal: ${p}</span>
        <span class="text-[9px] uppercase font-black tracking-wider px-2 py-0.5 rounded border border-slate-800 bg-slate-950/40 text-slate-400">Passing: ${h}</span>
        <span class="text-[9px] uppercase font-black tracking-wider px-2 py-0.5 rounded border border-slate-800 bg-slate-950/40 text-slate-400">AI: ${g}</span>
      </div>
      
      ${c?`<div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-900/50 border border-slate-800 px-3 py-1 rounded mb-6">Viewer</div>`:`<div class="mb-4"></div>`}

      <!-- Players grid -->
      <div class="grid grid-cols-2 gap-4 w-full mb-6">
        ${[0,1,2,3].map(t=>{let n=e[t];if(n){let e=n.id===`p1`,t=n.status===`Ready`,r=n.id===l.id,i=e?`Host`:t?`Ready`:`Not Ready`,a=e?`text-amber-400 border-amber-500/30 bg-amber-950/20`:t?`text-emerald-400 border-emerald-500/20 bg-emerald-950/10`:`text-slate-500 border-slate-800 bg-slate-900/40`;return`
              <div class="glass-opaque px-3 py-4 flex flex-col items-center border border-slate-800 hover:border-slate-700 hover:scale-[1.02] transition-all cursor-pointer player-card" data-id="${n.id}" data-name="${n.name}">
                <div class="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-base mb-2">
                  ${n.name.charAt(0).toUpperCase()}
                </div>
                <span class="text-xs font-bold text-white truncate max-w-full">${n.name} ${r?`<span class="text-[9px] text-slate-500">(You)</span>`:``}</span>
                <span class="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border mt-2 ${a}">${i}</span>
              </div>
            `}else return`
              <div class="glass-opaque px-3 py-4 flex flex-col items-center opacity-40 border border-slate-700/30 border-dashed animate-pulse">
                <div class="w-9 h-9 rounded-full bg-slate-800 text-slate-600 flex items-center justify-center font-bold text-base mb-2">
                  ?
                </div>
                <span class="text-xs font-semibold text-slate-500">Waiting</span>
                <span class="text-[9px] text-slate-600 font-medium uppercase mt-1.5">-</span>
              </div>
            `}).join(``)}
      </div>

      <!-- Controls -->
      <div class="flex flex-col gap-3 w-full mt-auto">
        <div class="flex items-center justify-center gap-2 text-slate-400 text-xs font-medium">
          <span class="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          <span>${s}/4 Players Connected</span>
        </div>

        <div class="flex gap-3 justify-center w-full mt-1">
          ${u?`
            <button id="btn-close-room" class="btn btn-secondary text-xs flex-1 !py-2.5 !px-3 border border-rose-500/20 hover:border-rose-500/40 text-rose-300">Close Room</button>
            <button id="btn-start-game" class="btn btn-primary text-xs flex-1 !py-2.5 !px-4">Start Game</button>
          `:`
            <button id="btn-exit-room" class="btn btn-secondary text-xs flex-1 !py-2.5 !px-3">Exit Room</button>
            ${c?``:`<button id="btn-ready-room" class="btn btn-primary text-xs flex-1 !py-2.5 !px-4">${d?`Unready`:`Ready Up`}</button>`}
          `}
        </div>
      </div>
    </div>

    ${a?`
      <!-- Divider -->
      <div class="hidden md:block w-px bg-slate-800 self-stretch"></div>

      <!-- Right Side: Chat Box -->
      <div class="w-full md:w-80 flex flex-col h-[320px] md:h-auto">
        <h3 class="text-xs font-bold text-slate-400 uppercase tracking-widest text-left mb-3">Room Chat</h3>
        
        <!-- Chat logs container -->
        <div id="chat-messages" class="flex-1 overflow-y-auto pr-1 bg-slate-950/50 border border-slate-800/80 rounded-xl p-3 flex flex-col gap-2 min-h-[160px] max-h-[220px] md:max-h-[300px] text-left">
          <div class="text-[10px] text-slate-500 italic text-center py-4">Welcome to the lobby chat. Say hello!</div>
        </div>
        
        <!-- Chat input form -->
        <form id="chat-form" class="flex gap-2 mt-3 pointer-events-auto">
          <input type="text" id="chat-input" class="input flex-1 !py-2 text-xs" placeholder="Type a message..." maxlength="100" autocomplete="off" />
          <button type="submit" class="btn btn-primary text-xs !py-2 !px-3.5">Send</button>
        </form>
      </div>
    `:``}
  `,t.appendChild(o);let _=o.querySelector(`#btn-exit-room`),v=o.querySelector(`#btn-ready-room`),y=o.querySelector(`#btn-close-room`),x=o.querySelector(`#btn-start-game`),S=o.querySelector(`#btn-waiting-room-settings`),C=o.querySelector(`#chat-form`),w=o.querySelector(`#chat-input`),T=o.querySelector(`#chat-messages`);a&&T&&B.length>0&&(T.innerHTML=``,B.forEach(t=>{let n=document.createElement(`div`);n.className=`text-xs text-slate-300 leading-normal`;let r=`text-emerald-400`;t.player_name===`Spectator`?r=`text-slate-400`:(t.player_name===`You`||t.player_name===e[0]?.name)&&(r=`text-amber-400`),n.innerHTML=`<span class="font-extrabold ${r}">${t.player_name}:</span> <span class="font-medium">${t.message}</span>`,T.appendChild(n)}),T.scrollTop=T.scrollHeight),window._chatListener&&window.removeEventListener(`whist_chat`,window._chatListener),window._chatListener=t=>{let n=t.detail;if(B.push(n),a&&T){let t=T.querySelector(`.italic`);t&&t.remove();let r=document.createElement(`div`);r.className=`text-xs text-slate-300 leading-normal`;let i=`text-emerald-400`;n.player_name===`Spectator`?i=`text-slate-400`:(n.player_name===`You`||n.player_name===e[0]?.name)&&(i=`text-amber-400`),r.innerHTML=`<span class="font-extrabold ${i}">${n.player_name}:</span> <span class="font-medium">${n.message}</span>`,T.appendChild(r),T.scrollTop=T.scrollHeight}},window.addEventListener(`whist_chat`,window._chatListener),S&&S.addEventListener(`click`,()=>{b(`Button Click: Open Waiting Room Settings`),z()}),_&&_.addEventListener(`click`,()=>{b(`Button Click: Exit Room`),_.disabled=!0,_.classList.add(`btn-loading`),m({action:`leave_room`}),B=[],window._chatListener&&(window.removeEventListener(`whist_chat`,window._chatListener),window._chatListener=null);let e=r()||{};e.view_stage=`ROOM_LIST`,n(e),m({action:`list_rooms`})}),v&&v.addEventListener(`click`,()=>{b(`Button Click: Ready Up / Unready`),v.disabled=!0,v.classList.add(`btn-loading`),m({action:`ready_toggle`})}),y&&y.addEventListener(`click`,()=>{b(`Button Click: Close Room`),q(`Are you sure you want to close this room? All players will be disconnected.`,()=>{b(`Button Click: Confirm Close Room`),y.disabled=!0,y.classList.add(`btn-loading`),m({action:`close_room`})})}),x&&x.addEventListener(`click`,()=>{b(`Button Click: Start Game Early (with bots)`),x.disabled=!0,x.classList.add(`btn-loading`),x.textContent=`Starting...`,m({action:`start_game`})}),a&&C&&w&&C.addEventListener(`submit`,e=>{e.preventDefault();let t=w.value.trim();t&&(b(`Form Submit: Send Chat message: "${t}"`),m({action:`chat`,message:t}),w.value=``,w.focus())}),o.querySelectorAll(`.player-card`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id,n=e.dataset.name;b(`Button Click: View Player Profile ID: ${t}, Name: ${n}`),K(t,n)})})}function K(e,t){let n=t.split(``).reduce((e,t)=>e+t.charCodeAt(0),0),r=n%80+20,i=n%25+40,a=[`hearts`,`diamonds`,`clubs`,`spades`][n%4],o=n%20+70,s=document.createElement(`div`);s.className=`fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 pointer-events-auto`,s.innerHTML=`
    <div class="glass-opaque p-6 max-w-sm w-full mx-4 border border-slate-800 flex flex-col items-center text-center shadow-2xl relative rounded-2xl animate-fade-in">
      <div class="w-16 h-16 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold text-3xl mb-4 border border-amber-500/25">
        ${t.charAt(0).toUpperCase()}
      </div>
      <h3 class="text-lg font-black text-white mb-1">${t}</h3>
      <div class="text-[9px] uppercase font-black tracking-widest text-slate-500 mb-6">Player Card ID: ${e}</div>

      <!-- Stats Grid -->
      <div class="grid grid-cols-2 gap-4 w-full mb-8">
        <div class="glass-sm p-3 flex flex-col items-center border border-slate-800/80">
          <span class="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Games Played</span>
          <span class="text-lg font-black text-white font-mono mt-1">${r}</span>
        </div>
        <div class="glass-sm p-3 flex flex-col items-center border border-slate-800/80">
          <span class="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Win Rate</span>
          <span class="text-lg font-black text-emerald-400 font-mono mt-1">${i}%</span>
        </div>
        <div class="glass-sm p-3 flex flex-col items-center border border-slate-800/80">
          <span class="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Favorite Suit</span>
          <span class="text-sm font-bold text-white mt-1 capitalize">${a}</span>
        </div>
        <div class="glass-sm p-3 flex flex-col items-center border border-slate-800/80">
          <span class="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Bids Met</span>
          <span class="text-lg font-black text-amber-400 font-mono mt-1">${o}%</span>
        </div>
      </div>

      <button id="btn-close-stats" class="btn btn-secondary w-full py-2.5 text-xs font-bold">
        Close Profile
      </button>
    </div>
  `,document.body.appendChild(s),s.querySelector(`#btn-close-stats`).addEventListener(`click`,()=>{s.remove()})}function q(e,t){let n=document.createElement(`div`);n.className=`fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 pointer-events-auto`,n.innerHTML=`
    <div class="glass-opaque p-6 max-w-sm w-full mx-4 border border-slate-800 flex flex-col items-center text-center shadow-2xl rounded-2xl animate-fade-in">
      <h3 class="text-base font-extrabold text-white mb-2">Confirm Action</h3>
      <p class="text-xs text-slate-400 mb-6 leading-relaxed">${e}</p>
      <div class="flex gap-3 w-full">
        <button id="confirm-cancel" class="btn btn-secondary flex-1 py-2 text-xs">Cancel</button>
        <button id="confirm-ok" class="btn btn-danger flex-1 py-2 text-xs">Confirm</button>
      </div>
    </div>
  `,document.body.appendChild(n);let r=n.querySelector(`#confirm-cancel`),i=n.querySelector(`#confirm-ok`);r.addEventListener(`click`,()=>{n.remove()}),i.addEventListener(`click`,()=>{n.remove(),t()})}var J={hearts:`♥`,diamonds:`♦`,clubs:`♣`,spades:`♠`},Y={hearts:`#ef4444`,diamonds:`#ef4444`,clubs:`#1e293b`,spades:`#1e293b`},X={2:`2`,3:`3`,4:`4`,5:`5`,6:`6`,7:`7`,8:`8`,9:`9`,10:`10`,11:`J`,12:`Q`,13:`K`,14:`A`};function Z(e,t={}){let{suit:n,value:r}=e,i=J[n]||`?`,a=Y[n]||`#1e293b`,o=X[r]||r,s=t.mini?28:t.small?68:90,c=t.mini?40:t.small?96:128,l=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);return l.setAttribute(`viewBox`,`0 0 70 100`),l.setAttribute(`width`,s),l.setAttribute(`height`,c),l.classList.add(`game-card`),l.innerHTML=`
    <!-- Card body -->
    <rect x="0.5" y="0.5" width="69" height="99" rx="8" ry="8"
          fill="#f8fafc" stroke="#cbd5e1" stroke-width="1"/>

    <!-- Top-left value + suit -->
    <text x="5" y="21" font-family="Inter, sans-serif" font-size="20" font-weight="900" fill="${a}">${o}</text>
    <text x="5" y="36" font-family="Inter, sans-serif" font-size="15" fill="${a}">${i}</text>

    <!-- Center suit (large) -->
    <text x="35" y="60" font-family="Inter, sans-serif" font-size="30" fill="${a}"
          text-anchor="middle" dominant-baseline="middle">${i}</text>

    <!-- Bottom-right value + suit (rotated) -->
    <g transform="rotate(180, 35, 50)">
      <text x="5" y="21" font-family="Inter, sans-serif" font-size="20" font-weight="900" fill="${a}">${o}</text>
      <text x="5" y="36" font-family="Inter, sans-serif" font-size="15" fill="${a}">${i}</text>
    </g>
  `,l.dataset.suit=n,l.dataset.value=r,l}function Q(e={}){let t=e.mini?28:e.small?68:90,n=e.mini?40:e.small?96:128,r=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);return r.setAttribute(`viewBox`,`0 0 70 100`),r.setAttribute(`width`,t),r.setAttribute(`height`,n),r.classList.add(`game-card`),r.innerHTML=`
    <!-- Card body -->
    <rect x="0.5" y="0.5" width="69" height="99" rx="8" ry="8"
          fill="#1e3a5f" stroke="#334155" stroke-width="1"/>

    <!-- Pattern border -->
    <rect x="5" y="5" width="60" height="90" rx="5" ry="5"
          fill="none" stroke="#3b82f6" stroke-width="1.5" opacity="0.4"/>

    <!-- Diamond pattern -->
    <g opacity="0.25" fill="#60a5fa">
      <polygon points="35,15 42,30 35,45 28,30"/>
      <polygon points="35,35 42,50 35,65 28,50"/>
      <polygon points="35,55 42,70 35,85 28,70"/>
      <polygon points="20,25 27,40 20,55 13,40"/>
      <polygon points="50,25 57,40 50,55 43,40"/>
      <polygon points="20,45 27,60 20,75 13,60"/>
      <polygon points="50,45 57,60 50,75 43,60"/>
    </g>

    <!-- Center emblem -->
    <circle cx="35" cy="50" r="10" fill="none" stroke="#60a5fa" stroke-width="1.5" opacity="0.5"/>
    <text x="35" y="54" font-family="Inter, sans-serif" font-size="10" font-weight="700"
          fill="#93c5fd" text-anchor="middle" opacity="0.6">W</text>
  `,r}function te(e,t){t.innerHTML=``;let n=e.players||[],r=document.createElement(`div`);r.className=`table-felt w-full max-w-4xl h-[420px] rounded-[40px] relative overflow-hidden flex items-center justify-center`,r.innerHTML=`
    <div class="absolute inset-10 border border-emerald-800/20 rounded-[30px] pointer-events-none"></div>
    <div class="absolute inset-0 flex items-center justify-center">
      <div class="text-[10px] uppercase font-black tracking-widest text-emerald-950 select-none">WHIST DEALING</div>
    </div>
  `;let i=document.createElement(`div`);i.className=`absolute z-20 flex items-center justify-center`;for(let e=0;e<5;e++){let t=Q();t.style.position=`absolute`,t.style.transform=`translate(${-e*.5}px, ${-e*.5}px)`,t.style.boxShadow=`${e}px ${e}px 4px rgba(0,0,0,0.15)`,i.appendChild(t)}r.appendChild(i);let a=[{x:`0px`,y:`140px`,rot:`0deg`},{x:`-220px`,y:`0px`,rot:`90deg`},{x:`0px`,y:`-140px`,rot:`0deg`},{x:`220px`,y:`0px`,rot:`-90deg`}],o=0;for(let e=0;e<13;e++)for(let e=0;e<4;e++){if(!n[e])continue;let t=a[e],i=Q({small:!0});i.style.position=`absolute`,i.style.setProperty(`--deal-x`,t.x),i.style.setProperty(`--deal-y`,t.y),i.style.setProperty(`--deal-rot`,t.rot),i.style.setProperty(`--deal-delay`,`${o*.05}s`),i.classList.add(`deal-animate`),r.appendChild(i),o++}let s=[`bottom-2 left-1/2 -translate-x-1/2`,`left-2 top-1/2 -translate-y-1/2`,`top-2 left-1/2 -translate-x-1/2`,`right-2 top-1/2 -translate-y-1/2`];for(let e=0;e<4;e++){let t=n[e];if(!t)continue;let i=document.createElement(`div`);i.className=`absolute ${s[e]} glass-sm px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-300 z-10`,i.textContent=e===0?`You`:t.name,r.appendChild(i)}t.appendChild(r)}function ne(e,t){t.innerHTML=``;let n=(e.players||[])[0]||{name:`You`,is_turn:!1},r=e.prompt_data||{bidding_stage:`SUIT`,min_bet:5,max_bet:13},i=e.my_hand||[],a=(r.bidding_stage||`SUIT`).toUpperCase(),o=a===`EXCHANGE`,s=document.createElement(`div`);s.className=`w-full h-full flex flex-col justify-between items-center p-4 relative`;let c=document.createElement(`div`);c.className=`table-felt w-full max-w-4xl flex-1 rounded-[40px] relative overflow-hidden flex flex-col items-center justify-center min-h-[220px] mt-16 md:mt-24 mb-4`;let l=document.createElement(`div`);l.className=`text-center z-0`,n.is_turn?o?l.innerHTML=`
        <div class="text-xs uppercase font-extrabold tracking-widest text-amber-400 mb-2 pulse-soft">Card Exchange Phase</div>
        <div class="text-sm font-semibold text-slate-400">Select exactly 2 cards from your hand to pass clockwise.</div>
      `:r.bidding_stage===`TAKES`?l.innerHTML=`
        <div class="text-xs uppercase font-extrabold tracking-widest text-emerald-500/60 mb-2">Bid Your Expected Tricks</div>
        <div class="text-sm font-semibold text-slate-400">The total sum of all player bids cannot be exactly 13.</div>
      `:l.innerHTML=`
        <div class="text-xs uppercase font-extrabold tracking-widest text-emerald-500/60 mb-2">Declare Contract Suit</div>
        <div class="text-sm font-semibold text-slate-400">Bid at least 5 takes to set the contract, or select Skip.</div>
      `:l.innerHTML=`
      <div class="text-xs uppercase font-extrabold tracking-widest text-amber-500/60 mb-2">Waiting For Players</div>
      <div class="text-sm font-semibold text-slate-400 flex items-center justify-center gap-1">
        <span>Opponents are making their choices</span>
        <span class="inline-flex">
          <span class="thinking-dot"></span>
          <span class="thinking-dot"></span>
          <span class="thinking-dot"></span>
        </span>
      </div>
    `,c.appendChild(l),s.appendChild(c);let u=[];if(n.is_turn){let e=document.createElement(`div`);if(e.className=`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 glass-opaque p-6 max-w-md w-full shadow-2xl flex flex-col items-center border border-emerald-500/20`,o){e.innerHTML=`
        <h3 class="text-lg font-black text-white uppercase tracking-wider mb-1">Exchange Cards</h3>
        <p class="text-slate-400 text-[11px] font-medium mb-6">Choose 2 cards to pass to the next player</p>
        <div class="w-full flex flex-col items-center gap-4">
          <div class="text-slate-400 text-xs font-semibold" id="exchange-count">0 of 2 Selected</div>
          <button id="btn-confirm-exchange" class="btn btn-primary w-full py-3" disabled>Confirm Exchange</button>
        </div>
      `;let t=e.querySelector(`#btn-confirm-exchange`);t.addEventListener(`click`,()=>{u.length===2&&(b(`Button Click: Confirm Exchange (cards: ${JSON.stringify(u)})`),t.disabled=!0,t.classList.add(`btn-loading`),e.querySelector(`h3`).textContent=`Submitting...`,m({action:`exchange_cards`,cards:u}))}),s.appendChild(e)}else if(a===`SUIT`){e.innerHTML=`
        <h3 class="text-lg font-black text-white uppercase tracking-wider mb-1">Select Trump & Bid</h3>
        <p class="text-slate-400 text-[11px] font-medium mb-4">Choose a suit and bid at least ${r.min_bet} takes</p>
        
        <div class="w-full flex flex-col gap-4">
          <!-- Suit buttons -->
          <div class="flex flex-col gap-1.5">
            <label class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Trump Suit</label>
            <div class="grid grid-cols-5 gap-1.5 w-full" id="suit-buttons-container">
              <button data-suit="no_trump" class="btn btn-gold py-2 px-1 text-xs font-bold border border-slate-700/50">NT</button>
              <button data-suit="spades" class="btn btn-secondary py-2 px-1 text-xs font-bold border border-slate-700/50">♠</button>
              <button data-suit="hearts" class="btn btn-secondary py-2 px-1 text-xs font-bold border border-slate-700/50 text-rose-500">♥</button>
              <button data-suit="diamonds" class="btn btn-secondary py-2 px-1 text-xs font-bold border border-slate-700/50 text-amber-500">♦</button>
              <button data-suit="clubs" class="btn btn-secondary py-2 px-1 text-xs font-bold border border-slate-700/50 text-emerald-400">♣</button>
            </div>
          </div>

          <!-- Takes select slider -->
          <div class="flex flex-col items-center gap-2">
            <label class="text-[10px] uppercase font-bold text-slate-400 tracking-wider self-start">Minimum Bid: ${r.min_bet}</label>
            <div class="text-3xl font-black text-amber-400 font-mono" id="slider-val">${r.min_bet}</div>
            <input type="range" min="${r.min_bet}" max="13" value="${r.min_bet}" class="w-full accent-amber-400 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none" id="bet-slider" />
          </div>

          <!-- Actions -->
          <div class="flex gap-3 mt-2">
            <button id="btn-skip-bid" class="btn btn-secondary flex-1 py-3">Skip</button>
            <button id="btn-confirm-bid" class="btn btn-primary flex-1 py-3">Bid</button>
          </div>
        </div>
      `;let t=`no_trump`,n=e.querySelector(`#suit-buttons-container`).querySelectorAll(`button`);n.forEach(e=>{e.addEventListener(`click`,()=>{b(`Button Click: Select Trump Suit: "${e.dataset.suit}"`),n.forEach(e=>{e.className=e.className.replace(`btn-gold`,`btn-secondary`),e.className.includes(`btn-secondary`)||(e.className+=` btn-secondary`)}),e.className=e.className.replace(`btn-secondary`,`btn-gold`),t=e.dataset.suit})});let i=e.querySelector(`#bet-slider`),a=e.querySelector(`#slider-val`),o=e.querySelector(`#btn-confirm-bid`),c=e.querySelector(`#btn-skip-bid`);i.addEventListener(`input`,e=>{a.textContent=e.target.value}),o.addEventListener(`click`,()=>{let n=parseInt(i.value,10);b(`Button Click: Confirm Suit Bid (takes: ${n}, suit: "${t}")`),o.disabled=!0,c.disabled=!0,o.classList.add(`btn-loading`),e.querySelector(`h3`).textContent=`Submitting...`,m({action:`bet`,takes:n,suit:t})}),c.addEventListener(`click`,()=>{b(`Button Click: Skip Suit Bid`),o.disabled=!0,c.disabled=!0,c.classList.add(`btn-loading`),e.querySelector(`h3`).textContent=`Skipping...`,m({action:`bet`,takes:0,suit:`skip`})}),s.appendChild(e)}else{let t=r.min_bet,n=r.max_bet,i=r.restricted_bet,a=t;a===i&&(a+1<=n?a+=1:a-1>=t&&--a),e.innerHTML=`
        <h3 class="text-lg font-black text-white uppercase tracking-wider mb-1">Make Your Bid</h3>
        <p class="text-slate-400 text-[11px] font-medium mb-4" id="bid-limit-msg">Choose a bid from ${t} to ${n}</p>
        
        <div class="w-full flex flex-col items-center gap-4">
          <div class="text-4xl font-black text-amber-400 font-mono" id="slider-val">${a}</div>
          <input type="range" min="${t}" max="${n}" value="${a}" class="w-full accent-amber-400 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none" id="bet-slider" />
          <div id="restricted-warning" class="text-rose-400 text-xs font-bold hidden">Sum cannot be 13. This bid is disabled.</div>
          <button id="btn-confirm-bet" class="btn btn-primary w-full py-3 mt-2">Confirm Bet</button>
        </div>
      `;let o=e.querySelector(`#bet-slider`),c=e.querySelector(`#slider-val`),l=e.querySelector(`#restricted-warning`),u=e.querySelector(`#btn-confirm-bet`),d=e=>{i!==void 0&&e===i?(l.classList.remove(`hidden`),u.disabled=!0,u.classList.add(`opacity-50`,`cursor-not-allowed`)):(l.classList.add(`hidden`),u.disabled=!1,u.classList.remove(`opacity-50`,`cursor-not-allowed`))};d(a),o.addEventListener(`input`,e=>{let t=parseInt(e.target.value,10);c.textContent=t,d(t)}),u.addEventListener(`click`,()=>{let t=parseInt(o.value,10);b(`Button Click: Confirm Takes Bid (takes: ${t})`),u.disabled=!0,o.disabled=!0,u.classList.add(`btn-loading`),e.querySelector(`h3`).textContent=`Confirming...`,m({action:`bet`,takes:t})}),s.appendChild(e)}}let d=document.createElement(`div`);d.className=`w-full flex justify-center items-center h-28 relative mt-2 fanned-hand ${o&&n.is_turn?`pointer-events-auto`:`pointer-events-none`}`;let f={clubs:0,diamonds:1,spades:2,hearts:3},p=[...i].sort((e,t)=>{let n=f[e.suit]===void 0?99:f[e.suit],r=f[t.suit]===void 0?99:f[t.suit];return n===r?t.value-e.value:n-r}),h=p.length;p.forEach((e,t)=>{let r=Z(e);r.style.position=`absolute`,r.style.left=`50%`;let i=(h-1)/2,a=parseFloat(localStorage.getItem(`whist_card_spacing`)||`32`),s=(t-i)*a,c=(t-i)*2.5;r.style.setProperty(`--card-offset`,`${s}px`),r.style.setProperty(`--card-rot`,`${c}deg`),r.style.transformOrigin=`50% 120%`,r.style.boxShadow=`0 4px 12px rgba(0,0,0,0.3)`,o&&n.is_turn&&(r.classList.add(`playable`),r.addEventListener(`click`,()=>{if(r.classList.contains(`selected`)){b(`Card Click: Deselect card for exchange (suit: "${e.suit}", value: ${e.value})`),r.classList.remove(`selected`);let t=u.findIndex(t=>t.suit===e.suit&&t.value===e.value);t>-1&&u.splice(t,1)}else u.length<2&&(b(`Card Click: Select card for exchange (suit: "${e.suit}", value: ${e.value})`),r.classList.add(`selected`),u.push(e));let t=document.getElementById(`exchange-count`),n=document.getElementById(`btn-confirm-exchange`);t&&(t.textContent=`${u.length} of 2 Selected`),n&&(n.disabled=u.length!==2)})),d.appendChild(r)}),s.appendChild(d),t.appendChild(s)}function re(e,t){t.innerHTML=``;let n=e.players||[],r=n[0]||{id:`p1`,is_turn:!1},i=e.table_cards||[],a=e.my_hand||[],o=document.createElement(`div`);o.className=`w-full h-full flex flex-col justify-between items-center p-4 relative`;let s=document.createElement(`div`);s.className=`table-felt w-full max-w-4xl flex-1 rounded-[40px] relative overflow-hidden flex items-center justify-center min-h-[220px] mt-16 md:mt-24 mb-4`;let c=document.createElement(`div`);c.className=`grid grid-cols-3 grid-rows-3 gap-3 items-center justify-items-center w-72 h-72 relative z-10`;let l=[{row:3,col:2,name:`bottom`},{row:2,col:1,name:`left`},{row:1,col:2,name:`top`},{row:2,col:3,name:`right`}],u=e=>{let t=i.find(t=>t.player_id===e);return t?t.card:null};for(let e=1;e<=3;e++)for(let t=1;t<=3;t++){let r=document.createElement(`div`),a=l.findIndex(n=>n.row===e&&n.col===t);if(a!==-1){let e=n[a];if(r.className=`flex flex-col items-center justify-center gap-1 w-20 h-28 relative`,e){let t=u(e.id);if(t){let n=Z(t,{small:!0});n.style.boxShadow=`0 6px 12px rgba(0,0,0,0.3)`,r.appendChild(n);let i=document.createElement(`div`);i.className=`text-[9px] font-bold text-slate-300 uppercase mt-1 bg-slate-950/60 px-1.5 py-0.5 rounded`,i.textContent=a===0?`You`:e.name,r.appendChild(i)}else r.className+=` border-2 border-dashed border-slate-700/30 rounded-lg flex items-center justify-center`,r.innerHTML=`
              <div class="text-[9px] font-black text-slate-600 uppercase text-center">
                ${a===0?`You`:e.name}
              </div>
            `}}else if(e===2&&t===2){r.className=`flex flex-col items-center justify-center w-full h-full text-center`;let e=e=>{switch(e){case`spades`:return`♠`;case`hearts`:return`♥`;case`diamonds`:return`♦`;case`clubs`:return`♣`;default:return``}},t=e=>e?e.charAt(0).toUpperCase()+e.slice(1):``;if(i.length>0){let n=i[0].card.suit;r.innerHTML=`
            <span class="text-[8px] font-bold text-emerald-500/40 uppercase tracking-widest">LEAD SUIT</span>
            <span class="text-sm font-black text-emerald-400 mt-1">${e(n)} ${t(n)}</span>
          `}else r.innerHTML=`
            <span class="text-[8px] font-bold text-emerald-600/40 uppercase tracking-widest">TABLE</span>
          `}else r.className=`w-20 h-28`;c.appendChild(r)}s.appendChild(c),o.appendChild(s);let d=document.createElement(`div`);d.className=`w-full flex justify-center items-center h-28 relative mt-2 pointer-events-auto fanned-hand`;let f={clubs:0,diamonds:1,spades:2,hearts:3},p=[...a].sort((e,t)=>{let n=f[e.suit]===void 0?99:f[e.suit],r=f[t.suit]===void 0?99:f[t.suit];return n===r?t.value-e.value:n-r}),h=p.length,g=r.is_turn;p.forEach((e,t)=>{let n=Z(e);n.style.position=`absolute`,n.style.left=`50%`;let r=(h-1)/2,a=parseFloat(localStorage.getItem(`whist_card_spacing`)||`32`),o=(t-r)*a,s=(t-r)*2.5;n.style.setProperty(`--card-offset`,`${o}px`),n.style.setProperty(`--card-rot`,`${s}deg`),n.style.transformOrigin=`50% 120%`,n.style.boxShadow=`0 4px 12px rgba(0,0,0,0.3)`,g&&(()=>{if(i.length===0)return!0;let t=i[0].card.suit;return e.suit===t?!0:!p.some(e=>e.suit===t)})()?(n.classList.add(`playable`),n.addEventListener(`click`,()=>{b(`Card Play Click: Playing card (suit: "${e.suit}", value: ${e.value})`),d.querySelectorAll(`.game-card`).forEach(e=>{e.classList.add(`disabled`),e.classList.remove(`playable`)}),m({action:`play_card`,card:{suit:e.suit,value:e.value}})})):g?n.classList.add(`unplayable`):n.classList.add(`disabled`),d.appendChild(n)}),o.appendChild(d),t.appendChild(o)}function ie(e,t){t.innerHTML=``;let n=e.players||[],r=e.game_stats||{round:1},i=document.createElement(`div`);i.className=`w-full h-full flex flex-col justify-center items-center p-4 bg-slate-950/90 backdrop-blur-md z-30 relative`;let a=document.createElement(`div`);a.className=`text-center mb-8 banner-animate`,a.innerHTML=`
    <h2 class="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-yellow-500 uppercase tracking-widest leading-none">Round Completed</h2>
    <p class="text-slate-400 text-sm mt-2 font-medium">Round ${r.round} final standings & score adjustments</p>
  `,i.appendChild(a);let o=document.createElement(`div`);o.className=`glass p-6 w-full max-w-2xl border border-slate-800 shadow-2xl mb-8 relative z-10`;let s=document.createElement(`table`);s.className=`w-full text-left border-collapse`,s.innerHTML=`
    <thead>
      <tr class="border-b border-slate-800 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
        <th class="pb-3 px-2">Player</th>
        <th class="pb-3 px-2 text-center">Bid</th>
        <th class="pb-3 px-2 text-center">Tricks Taken</th>
        <th class="pb-3 px-2 text-center">Status</th>
        <th class="pb-3 px-2 text-center">Score Change</th>
        <th class="pb-3 px-2 text-right">Total Score</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-800/40">
      ${n.map((e,t)=>{let n=t===0,r=e.tricks_taken||0,i=e.bet!==null&&e.bet!==void 0?e.bet:0,a=r===i,o=e.score_change===void 0?a?10+i*i:-Math.abs(i-r)*10:e.score_change,s=o>=0?`+${o}`:`${o}`,c=o>=0?`text-emerald-400 font-extrabold`:`text-rose-500 font-extrabold`,l=a?`<span class="bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">Made</span>`:`<span class="bg-rose-500/10 text-rose-400 border border-rose-500/25 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">Missed</span>`,u=`text-slate-300`;return n&&(u=`text-white bg-slate-800/20 font-semibold`),`
          <tr class="${u}">
            <td class="py-3.5 px-2 text-sm">
              ${e.name} ${n?`<span class="text-[10px] text-slate-500 font-normal ml-1">(You)</span>`:``}
            </td>
            <td class="py-3.5 px-2 text-center font-mono font-bold">${i}</td>
            <td class="py-3.5 px-2 text-center font-mono font-bold">${r}</td>
            <td class="py-3.5 px-2 text-center">${l}</td>
            <td class="py-3.5 px-2 text-center font-mono ${c}">${s}</td>
            <td class="py-3.5 px-2 text-right font-mono font-black score-animate text-white">${e.score} <span class="text-[10px] text-slate-500 font-normal">pts</span></td>
          </tr>
        `}).join(``)}
    </tbody>
  `,o.appendChild(s),i.appendChild(o);let c=document.createElement(`button`);c.className=`btn btn-primary text-base px-8 py-3 relative z-10 flex items-center gap-2`,c.innerHTML=`<span>Next Round</span> <span>→</span>`,c.addEventListener(`click`,()=>{b(`Button Click: Ready for Next Round`),c.disabled=!0,c.textContent=`Waiting for players...`,m({action:`ready_next_round`})}),i.appendChild(c),t.appendChild(i)}function ae(e,t){t.innerHTML=``;let r=e.players||[],i=r[0]||{id:`p1`,name:`You`},a=e.winner||{id:``,name:`Unknown`},o=[...r].sort((e,t)=>t.score-e.score),s=document.createElement(`div`);s.className=`w-full h-full flex flex-col justify-center items-center p-4 bg-slate-950/95 z-30 relative overflow-hidden`;let c=a.id===i.id,l=c?50:15,u=[`#f59e0b`,`#10b981`,`#3b82f6`,`#ec4899`,`#ef4444`];for(let e=0;e<l;e++){let e=document.createElement(`div`);e.className=`particle`,e.style.backgroundColor=u[Math.floor(Math.random()*u.length)],e.style.left=`${Math.random()*100}%`,e.style.bottom=`0%`,e.style.animationDelay=`${Math.random()*2}s`,e.style.width=`${Math.random()*6+4}px`,e.style.height=e.style.width,s.appendChild(e)}let d=document.createElement(`div`);d.className=`glass banner-animate p-8 max-w-md w-full text-center border shadow-2xl mb-8 flex flex-col items-center relative z-10`,c?(d.classList.add(`border-amber-500/30`,`bg-amber-950/10`),d.innerHTML=`
      <div class="text-6xl mb-4 animate-bounce">🏆</div>
      <h1 class="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-500 tracking-wider mb-2">VICTORY!</h1>
      <p class="text-slate-300 text-sm font-semibold">Congratulations, you won the match!</p>
    `):(d.classList.add(`border-slate-800`,`bg-slate-900/40`),d.innerHTML=`
      <div class="text-5xl mb-4">🤝</div>
      <h1 class="text-3xl font-black text-slate-300 tracking-wider mb-2">GAME OVER</h1>
      <p class="text-slate-400 text-sm font-medium">Winner: <span class="text-amber-400 font-extrabold">${a.name}</span></p>
    `),s.appendChild(d);let f=document.createElement(`div`);f.className=`glass-sm p-6 w-full max-w-md border border-slate-800 shadow-xl mb-8 relative z-10`,f.innerHTML=`
    <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest text-center mb-4">Final Standings</h3>
  `;let p=document.createElement(`table`);p.className=`w-full text-left border-collapse`,p.innerHTML=`
    <thead>
      <tr class="border-b border-slate-800 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
        <th class="pb-2">Rank</th>
        <th class="pb-2">Player</th>
        <th class="pb-2 text-right">Final Score</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-800/40">
      ${o.map((e,t)=>{let n=e.id===a.id,r=e.id===i.id,o=`text-slate-300`;n?o=`text-amber-400 font-bold bg-amber-500/5`:r&&(o=`text-white font-medium bg-slate-800/20`);let s=t===0?`🥇`:t===1?`🥈`:t===2?`🥉`:`#${t+1}`;return`
          <tr class="${o}">
            <td class="py-3 px-1.5 text-sm">${s}</td>
            <td class="py-3 px-1.5 text-sm">
              ${e.name} ${r?`<span class="text-[10px] text-slate-500 font-normal ml-1">(You)</span>`:``}
            </td>
            <td class="py-3 px-1.5 text-sm font-mono font-black text-right">${e.score} <span class="text-[10px] text-slate-500 font-normal">pts</span></td>
          </tr>
        `}).join(``)}
    </tbody>
  `,f.appendChild(p),s.appendChild(f);let h=document.createElement(`button`);h.className=`btn btn-primary text-base px-8 py-3 relative z-10`,h.textContent=`Return to Lobby`,h.addEventListener(`click`,()=>{b(`Button Click: Return to Lobby from Game Over screen`),h.disabled=!0,h.textContent=`Resetting...`,m({action:`return_menu`}),n({current_stage:`LOBBY`,players:[],my_hand:[],table_cards:[],prompt_data:null,trick_winner:null,winner:null})}),s.appendChild(h),t.appendChild(s)}function oe(e,t){t.innerHTML=``;let n=e.players||[],r=e.game_stats||{round:0,target_score:100},i=g(),a=e.current_stage||`PLAYING`,o=document.createElement(`div`);o.className=`absolute top-2 right-2 md:top-4 md:right-4 flex items-center gap-2 md:gap-3 pointer-events-auto z-20`;let s=`status-dot disconnected`,c=`Disconnected`;if(i===`connected`?(s=`status-dot connected`,c=`Connected`):i===`connecting`&&(s=`status-dot connecting`,c=`Connecting...`),o.innerHTML=`
    <div class="glass-sm px-2 py-1 md:px-3 md:py-1.5 flex items-center gap-1.5 md:gap-2">
      <span class="${s}"></span>
      <span class="text-[10px] md:text-xs font-semibold text-slate-300">${c}</span>
    </div>
    <button id="btn-settings" class="btn btn-secondary text-[10px] md:text-xs !py-1 md:!py-1.5 !px-2 md:!px-3 flex items-center gap-1">
      ⚙️ Menu
    </button>
  `,t.appendChild(o),o.querySelector(`#btn-settings`).addEventListener(`click`,()=>{b(`Button Click: Open Settings Menu`),z()}),localStorage.getItem(`whist_show_round_stats`)!==`false`){let e=document.createElement(`div`);e.className=`absolute top-2 left-2 md:top-4 md:left-4 glass-sm px-2.5 py-1.5 md:px-4 md:py-2 flex flex-col justify-center pointer-events-auto z-20`;let n=r.play_style?` | Play: ${r.play_style}`:``,i=r.bidding_stage&&a===`BETTING`?` (${r.bidding_stage})`:``;e.innerHTML=`
      <div class="text-[8px] md:text-[9px] text-slate-400 font-bold uppercase tracking-wider">Israeli Whist${n}${r.trump_suit&&r.trump_suit!==`no_trump`?` | Trump: ${(e=>e?e.split(`_`).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(` `):``)(r.trump_suit)} ${(e=>{switch(e){case`spades`:return`♠`;case`hearts`:return`♥`;case`diamonds`:return`♦`;case`clubs`:return`♣`;default:return``}})(r.trump_suit)}`:r.trump_suit===`no_trump`?` | Trump: NT`:``}</div>
      <div class="text-sm md:text-xl font-black text-white font-mono leading-none mt-1">Round ${r.round}${i}</div>
      <div class="text-[9px] md:text-[10px] text-amber-400 font-semibold mt-0.5 md:mt-1">Target: ${r.target_score}</div>
    `,t.appendChild(e)}let l=[`bottom-28 left-2 md:bottom-32 md:left-6`,`left-2 md:left-6 top-[35%] -translate-y-1/2`,`top-2 md:top-4 left-1/2 -translate-x-1/2`,`right-2 md:right-6 top-[35%] -translate-y-1/2`],u=window.innerWidth<768;for(let e=0;e<4;e++){let r=n[e];if(!r)continue;let i=e===0,o=r.is_turn,s=r.status===`Thinking...`,c=document.createElement(`div`);if(c.className=`absolute ${l[e]} flex flex-col items-center pointer-events-auto transition-all duration-300 z-20`,r.status&&!i){let t=document.createElement(`div`),n=`bottom-full mb-2 left-1/2 -translate-x-1/2`;u||(e===1&&(n=`left-full ml-2 top-1/2 -translate-y-1/2`),e===3&&(n=`right-full mr-2 top-1/2 -translate-y-1/2`)),t.className=`absolute ${n} glass-sm px-2.5 py-1 text-[11px] font-semibold text-slate-200 border border-slate-700/50 shadow-lg whitespace-nowrap`,s?t.innerHTML=`
          <span>Thinking</span>
          <span class="inline-flex items-center ml-0.5">
            <span class="thinking-dot"></span>
            <span class="thinking-dot"></span>
            <span class="thinking-dot"></span>
          </span>
        `:t.textContent=r.status,c.appendChild(t)}let d=document.createElement(`div`);d.className=`glass-sm px-2 py-1.5 md:px-4 md:py-3 flex flex-col items-center min-w-24 md:min-w-32 border-2 transition-all duration-300 relative z-10 ${o?`turn-glow border-emerald-500`:`border-slate-700/30`}`;let f=``;if(a===`PLAYING`||a===`ROUND_END`){let e=r.tricks_taken||0,t=r.bet!==null&&typeof r.bet==`object`?r.bet.takes:r.bet;f=`
        <div class="text-[9px] md:text-[11px] font-bold mt-1 md:mt-1.5 flex flex-col items-center">
          <span class="text-slate-400 text-[8px] md:text-[9px] uppercase tracking-wider">Tricks</span>
          <span class="text-emerald-400 text-xs md:text-sm font-mono mt-0.5">${e} <span class="text-slate-500 text-[10px] md:text-xs">/ ${t!=null&&t!==`skip`?t:`-`}</span></span>
        </div>
      `}else r.bet!==null&&r.bet!==void 0&&r.bet!==`skip`&&(f=`
        <div class="text-[9px] md:text-[11px] font-bold mt-1 md:mt-1.5 flex flex-col items-center">
          <span class="text-slate-400 text-[8px] md:text-[9px] uppercase tracking-wider">Bet Bid</span>
          <span class="text-amber-400 font-mono mt-0.5 text-xs md:text-sm">${typeof r.bet==`object`?r.bet.takes:r.bet}</span>
        </div>
      `);let p=localStorage.getItem(`whist_show_opp_cards`)!==`false`&&(a===`PLAYING`||a===`BETTING`)&&!i,m=``;if(p&&u&&r.hand_size!==void 0&&(m=`
        <div class="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 mt-1 pt-1 border-t border-slate-800/30 w-full justify-center">
          <span>🎴</span>
          <span class="font-mono text-blue-400">${r.hand_size}</span>
        </div>
      `),d.innerHTML=`
      <div class="text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-wide truncate max-w-[80px] md:max-w-[120px]">${i?`You`:r.name}</div>
      <div class="text-sm md:text-lg font-black text-white font-mono mt-0.5">${r.score} <span class="text-[9px] md:text-xs text-amber-400 font-normal">Score</span></div>
      ${f}
      ${m}
      ${o?`<div class="text-[8px] md:text-[9px] text-emerald-400 font-extrabold uppercase tracking-wider animate-pulse mt-1">Your Turn</div>`:``}
    `,c.appendChild(d),p&&!u&&r.hand_size!==void 0){let n=document.createElement(`div`),i=``,a=0;e===1?(i=`absolute -left-4 top-[35%] -translate-y-1/2`,a=90):e===2?(i=`absolute -top-4 left-1/2 -translate-x-1/2`,a=180):e===3&&(i=`absolute -right-4 top-[35%] -translate-y-1/2`,a=-90),n.className=`${i} flex justify-center items-center h-10 w-48 z-10 pointer-events-none`;let o=r.hand_size,s=document.createElement(`div`);s.className=`relative h-10 w-full flex justify-center`,a!==0&&(s.style.transform=`rotate(${a}deg)`);for(let e=0;e<o;e++){let t=Q({mini:!0});t.style.position=`absolute`;let n=(o-1)/2,r=`translateX(${(e-n)*6}px)`,i=(e-n)*2;r+=` rotate(${i}deg)`,t.style.transform=r,t.style.transformOrigin=`50% 100%`,t.style.zIndex=e,s.appendChild(t)}n.appendChild(s),t.appendChild(n)}t.appendChild(c)}}window.showLoading=e=>{let t=document.getElementById(`loading-overlay`),n=document.getElementById(`loading-text`);t&&n&&(n.textContent=e||`Loading...`,t.classList.add(`active`))},window.hideLoading=()=>{let e=document.getElementById(`loading-overlay`);e&&e.classList.remove(`active`)};function $(){let e=localStorage.getItem(`whist_text_size`)||`18`;document.documentElement.style.fontSize=`${e}px`;let t=localStorage.getItem(`whist_felt_brightness`)||`100`;document.documentElement.style.setProperty(`--table-brightness`,parseFloat(t)/100),(localStorage.getItem(`whist_theme`)||`dark`)===`light`?document.body.classList.add(`light-theme`):document.body.classList.remove(`light-theme`),E(),D(`LOBBY`,V),D(`DEALING`,te),D(`BETTING`,ne),D(`PLAYING`,re),D(`ROUND_END`,ie),D(`GAME_OVER`,ae),i(e=>{O(e),window.hideLoading();let t=document.getElementById(`hud`);t&&[`DEALING`,`BETTING`,`PLAYING`,`ROUND_END`].includes(e.current_stage)&&oe(e,t)}),f(e=>{if(e&&e.type===`error`){ce(e.reason||e.error_type);let t=r();t&&n({...t})}else if(e&&e.type===`rooms_list`)n({...r()||{},rooms:e.rooms});else if(e&&e.type===`chat_message`){let t=new CustomEvent(`whist_chat`,{detail:e});window.dispatchEvent(t)}else if(e&&e.type===`room_closed`){ce(`Room closed by host.`);let e=r()||{};e.players=[],e.view_stage=`ROOM_LIST`,n(e)}else n(e)}),n({current_stage:`LOBBY`,players:[],my_hand:[],table_cards:[],prompt_data:null,trick_winner:null,winner:null})}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,$):$();var se={must_follow_suit:`Must follow the lead suit!`,card_not_in_hand:`Card is not in your hand!`,not_your_turn:`It's not your turn!`};function ce(e){let t=se[e]||e,n=document.getElementById(`toast-container`);n||(n=document.createElement(`div`),n.id=`toast-container`,n.className=`fixed top-6 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 pointer-events-none w-full max-w-sm px-4`,document.body.appendChild(n));let r=document.createElement(`div`);r.className=`glass-sm px-4 py-3 shadow-2xl border border-rose-500/30 text-xs font-bold text-rose-200 flex items-center justify-center gap-2 transition-all duration-300 transform -translate-y-4 opacity-0 pointer-events-auto cursor-pointer`;let i=document.createElement(`span`);i.textContent=`⚠️`,i.className=`text-rose-400 text-sm`,r.appendChild(i);let a=document.createElement(`span`);a.textContent=t,r.appendChild(a),r.addEventListener(`click`,()=>{r.remove()}),n.appendChild(r),requestAnimationFrame(()=>{r.classList.remove(`-translate-y-4`,`opacity-0`)}),setTimeout(()=>{r.parentNode&&(r.classList.add(`-translate-y-4`,`opacity-0`),r.addEventListener(`transitionend`,()=>{r.remove(),n.children.length===0&&n.remove()}))},3e3)}